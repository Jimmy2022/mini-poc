package org.jimmy.jettydemo;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.SocketConfig;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.eclipse.jetty.server.Connector;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;
import org.eclipse.jetty.servlet.ServletContextHandler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;

@Slf4j
public class JettyTest {

    private Server server;
    public static CloseableHttpClient client = HttpClients.custom().
            setDefaultSocketConfig(
                    SocketConfig.custom().setRcvBufSize(10240).setSndBufSize(1).setSoTimeout(1).build())
            .build();
    private static final String host = "192.168.166.26";
    private static final int port = 8080;

    public void serverConfig() {
        server = new Server();
        ServerConnector connector = new ServerConnector(server);
        connector.setPort(8080);
        server.setConnectors(new Connector[]{connector});
    }

    public void run() throws Exception {
        serverConfig();
        ServletContextHandler context = new ServletContextHandler(server, "/");
        context.addServlet(DemoServlet.class, "/");
        server.start();
    }

    /* https://github.com/eclipse/jetty.project#embedded-example */
    public static void main(String[] args) throws Exception {
        new JettyTest().run();
        new Thread(JettyTest::sendingBySocket).start();
    }

    private static void sendingByClient() {
        try {
            HttpPost request = new HttpPost(String.format("http://%s:%d", host, port));
            StringEntity entity = new StringEntity(RandomStringUtils.randomAlphabetic(102400));
            request.setEntity(entity);
            int i = 0;
            while (true) {
                try {
                    Thread.sleep(1000);
                    log.info("{}", i++);
                    String res = client.execute(request, new BasicResponseHandler());
                    log.info("res:{}", res);
                } catch (Exception exception) {
                    if (exception instanceof IllegalStateException) {
                        return;
                    }
                    if (!(exception instanceof SocketTimeoutException)) {
                        log.warn("error:", exception);
                    } else {
                        log.warn("timeout");
                    }

                }
            }
        } catch (Exception ignored) {

        }
    }

    @SneakyThrows
    private static void sendingBySocket() {
        InetAddress addr = InetAddress.getByName(host);
        Socket socket = new Socket(addr, port);
        socket.setSoLinger(true, 0);
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        // send an HTTP request to the web server
        sendHttpBySocket(socket, out, null);
        char[] contentChars = new char[128];
        in.read(contentChars);
        log.info("rsp:{}", new String(contentChars));
    }

    public static void sendHttpBySocket(PrintWriter out, char content) {
        out.println(content);
    }


    public static void sendHttpBySocket(Socket socket, PrintWriter out, String content) {
        if (StringUtils.isAllBlank(content)) {
            content = RandomStringUtils.randomAlphabetic(10240);
        }
        int len = content.length();
        out.println("POST / HTTP/1.1");
        out.println("Host: baidu.com:80");
        out.println("Content-Length: " + len);
        out.println("Content-Type: text/plain");
        out.println("Accept: */*");
        out.println();
        closeSocketAsync(socket);
        out.println(content);
    }

    public static void closeSocketAsync(Socket socket) {
        new Thread(() -> {
            try {
                Thread.sleep(12);
                socket.close();
            } catch (Exception e) {
                log.warn("close socket fail:{}", e);
            }
        }).start();
    }
}
